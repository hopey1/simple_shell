Team pproject 0x16. C - Simple Shell bi ali abdela and sami birhanu
